$(function() {
	//Hide error message
	$("#name_err_msg").hide();
	$("#contact_err_msg").hide();
	$("#email_err_msg").hide();
	$("#gender_err_msg").hide();
	$("#ddlCountry_err_msg").hide();
	$("#comment_err_msg").hide();
	/*$("#date_err_msg").hide();*/
	
	//Set the error function to false
	var error_name = false;
	var error_contact = false;
	var error_email = false;
	var error_gender = false;
	var error_country = false;
	var error_comment = false;
	/*var error_date = false;*/
	
	/*------Call Function-------*/
	$("#name").focusout(function() {
		check_name();
	});
	
	$("#contact").focusout(function() {
		check_contact();
	});
	
	$("#email").focusout(function() {
		check_email();
	});

	$("#gender").focusout(function() {
		check_gender();
	});

	$("#ddlCountry").focusout(function() {
		check_country();
	});
	
	$("#comment").focusout(function() {
		check_comment();
	});
	
	/*$("#date").focusout(function() {
		check_date();
	});*/
	
	/*--------------- Check Name ---------------*/
	function check_name() {
		if( ($("#name").val())== ""){
			$("#name_err_msg").html("Name cannot be blank! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#name_err_msg").show();
			$("#name_valid_msg").hide();
			$("#name").css("border", "1px solid red");
			$("#submit").prop('disabled', true);
			error_name = true;
		}  
		else {	
			$("#name_valid_msg").html("Valid! <i class='fas fa-check-circle'></i>");
			$("#name_valid_msg").show();
			$("#name_err_msg").hide();
			$("#name").css("border", "1px solid green");
			$("#submit").prop('disabled', false);
			
		}
	}
		
	/*--------------- Check Contact ---------------*/
	function check_contact() {
		var con_pattern = new RegExp( /^([0-9]{10,11})$/i);
		if( ($("#contact").val())== ""){
			$("#contact_err_msg").html("Contact cannot be blank! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#contact_err_msg").show();
			$("#contact_valid_msg").hide();
			$("#contact").css("border", "1px solid red");
			$("#submit").prop('disabled', true);
			error_contact = true;
		}
		else if(con_pattern.test($("#contact").val())) {
			$("#contact_err_msg").hide();
			$("#contact_valid_msg").html("Valid! <i class='fas fa-check-circle'></i>");
			$("#contact").css("border", "1px solid green");
			$("#contact_valid_msg").show();
			$("#submit").prop('disabled', false);
		} else {
			$("#contact_err_msg").html("Invalid Format! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#contact").css("border", "1px solid red");
			$("#contact_err_msg").show();
			$("#contact_valid_msg").hide();
			$("#submit").prop('disabled', true);
			error_contact = true;
		}
	}
	
	/*--------------- Check Email ---------------*/
	function check_email() {
		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
		if( ($("#email").val())== ""){
			$("#email_err_msg").html("Email cannot be blank! &nbsp;&nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#email").css("border", "1px solid red");
			$("#email_err_msg").show();
			$("#email_valid_msg").hide();
			$("#submit").prop('disabled', true);
			error_email = true;
		}
		else if(pattern.test($("#email").val())) {
			$("#email_valid_msg").html("Valid! <i class='fas fa-check-circle'></i>");
			$("#email").css("border", "1px solid green");
			$("#email_valid_msg").show();
			$("#email_err_msg").hide();
			$("#submit").prop('disabled', false);
		} else {
			$("#email_err_msg").html("Invalid Format! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#email").css("border", "1px solid red");
			$("#email_err_msg").show();
			$("#email_valid_msg").hide();
			$("#submit").prop('disabled', true);
			error_email = true;
		}
	}
	
	/*--------------- Check Gender ---------------*/
	 function check_gender() {    
        var getSelectedValue = document.querySelector(   
                'input[id="gender"]:checked');   
                
            if(getSelectedValue == null) {   
                $("#gender_err_msg").html("No Gender Selected! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
				$("#gender_err_msg").show();
				$("#gender_valid_msg").hide();
				$("#submit").prop('disabled', true);
				error_gender = true;  
            }   
            else if (getSelectedValue != null){   
                $("#gender_valid_msg").html("Valid! <i class='fas fa-check-circle'></i>");
				$("#gender_valid_msg").show();
				$("#gender_err_msg").hide();
				$("#submit").prop('disabled', false);  
				error_gender = false;  
            }   
        }   
	
	/*--------------- Check Country ---------------*/
	function check_country() {
		var ddl = document.getElementById("ddlCountry");
			if (ddl.value == "") {
				$("#country_err_msg").html("No Country Selected! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
				$("#ddlCountry").css("border", "1px solid red");
				$("#country_err_msg").show();
				$("#country_valid_msg").hide();
				$("#submit").prop('disabled', true);
				error_country = true;            
			}
			else if (ddl.value != ""){
				$("#country_valid_msg").html("Valid! <i class='fas fa-check-circle'></i>");
				$("#ddlCountry").css("border", "1px solid green");
				$("#country_valid_msg").show();
				$("#country_err_msg").hide();
				$("#submit").prop('disabled', false);
				error_country = false; 
			}
        
	}
	/*--------------- Check Comment ---------------*/
	function check_comment() {
		if( ($("#comment").val())== ""){
			$("#comment_err_msg").html("Comment cannot be blank! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#comment_err_msg").show();
			$("#comment_valid_msg").hide();
			$("#comment").css("border", "1px solid red");
			$("#submit").prop('disabled', true);
			error_comment = true;
		}  
		else {	
			$("#comment_valid_msg").html("Valid! <i class='fas fa-exclamation-circle'></i>");
			$("#comment_valid_msg").show();
			$("#comment_err_msg").hide();
			$("#comment").css("border", "1px solid green");
			$("#submit").prop('disabled', false);
			
		}
	}
	
	/*--------------- Check Date ---------------
	function check_date() {
		if( ($("#date").val())== ""){
			$("#date_err_msg").html("Date cannot be blank! &nbsp;&nbsp;<i class='fas fa-exclamation-circle'></i>");
			$("#date_err_msg").show();
			$("#date_valid_msg").hide();
			$("#date").css("border", "1px solid red");
			$("#submit").prop('disabled', true);
			error_date = true;
		}  
		else {	
			$("#date_valid_msg").html("Valid! <i class='fas fa-exclamation-circle' </i>");
			$("#date_valid_msg").show();
			$("#date_err_msg").hide();
			$("#date").css("border", "1px solid green");
			$("#submit").prop('disabled', false);
			//If the "Please Select" option is selected display error.
            alert("Please select an option!");
            return false;
		}
	}*/
		
	/*------------------------------------ Button triggered to check ------------------------------------*/
	$("#contact_form").submit(function() {
	
		error_name = false;
		error_contact = false;
		error_email = false;
		error_gender = false;
		error_country = false;
		error_comment = false;
		/*error_date = false;*/

		check_name();
		check_contact();
		check_email();
		check_gender();
		check_country();
		check_comment();
		/*check_date();*/
		
		
		if(error_name != false || error_contact!=false || error_email!=false || error_gender!=false || error_country!=false || error_comment!=false) {
			alert("Please fill in all fields!");
			return false;
			
		} else {
			window.location =  "https://www.tutorialspoint.com";
			return true;
			alert("Thank you and Stay Safe!");
		}

	});	
	
});